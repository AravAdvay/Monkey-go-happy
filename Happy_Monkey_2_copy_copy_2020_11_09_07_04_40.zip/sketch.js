var monkey, monkey_running
var banana, bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var backgroundImage


function preload() {

  backgroundImage = loadImage("jungleB.jpg")


  monkey_running = loadAnimation("sprite_0.png", "sprite_1.png", "sprite_2.png", "sprite_3.png", "sprite_4.png", "sprite_5.png", "sprite_6.png", "sprite_7.png", "sprite_8.png")

  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");

}



function setup() {
  createCanvas(600, 350);


  background = createSprite(0, 0, 600, 600);
  background.addImage(backgroundImage);
  background.scale = 2;



  monkey = createSprite(80, 280, 20, 20);
  monkey.addAnimation( "moving",monkey_running);
  monkey.scale = 0.1;

  ground = createSprite(80, 350, 1000, 10);
  ground.x = ground.width / 2;
  ground.velocityX = -4
  console.log(ground.x);
  ground.visible = true;


  var survivalTime = 0;


  obstacleGroup = new Group();
  foodGroup = new Group();

}


function draw() {

  background.velocityX = -3

  if (background.x < 0) {
    background.x = background.width / 2;
  }





  if (keyDown('space') && monkey.y > 300) {
    monkey.velocityY = -13;
  }

  monkey.velocityY = monkey.velocityY + 0.6;

  monkey.collide(ground);

  if (ground.x < 0) {
    ground.x = ground.width / 2;
  }

  if (monkey.isTouching(foodGroup)) {
    //survivalTime = survivalTime + 2;
    score = score + 2;
    foodGroup.destroyEach();

  }

  if (monkey.isTouching(obstacleGroup)) {
    monkey.scale = 0.1;
    score = score - 2;
  }



  food();
  obstacles();

  drawSprites();
  console.log(monkey.y)

  stroke("white");
  textSize = 20;
  fill("white");
  text("Score: " + score, 500, 50);

  stroke("black");
  textSize = 20;
  fill("black");
  survivalTime = Math.ceil(frameCount / frameRate())
  text("Survival Time: " + survivalTime, 100, 50);

}

function food() {
  if (frameCount % 80 === 0) {
    var food = createSprite(600, Math.round(random(130, 200)), 20, 20);
    food.addImage(bananaImage);
    food.velocityX = -3
    food.lifetime = 200;
    food.scale = 0.1;

    monkey.depth = food.depth;
    monkey.depth += 1;

    foodGroup.add(food);
  }
}

function obstacles() {
  if (frameCount % 200 === 0) {
    var obstacles = createSprite(600, 330, 20, 20);
    obstacles.addImage(obstacleImage);
    obstacles.velocityX = -3
    obstacles.lifetime = 200;
    obstacles.scale = 0.1;

    monkey.depth = obstacles.depth;
    monkey.depth += 1;

    obstacleGroup.add(obstacles);

  }
}